####################################
### Setting work directory

setwd("U:/Selection Model (APC)")

####################################
### Loading the required files

load("U:/Selection Model (APC)/Model_RAW_Data.RData")

#############################
### RF on the datasets

library(randomForest)
library(data.table)
library(caret)

###############
### Split data into Train, Test and Validation

Sample = sample(3, nrow(Final_Data), replace = TRUE, prob = c(0.6, 0.2, 0.2))
train_data = Final_Data[Sample==1,]
test_data = Final_Data[Sample==2,]
valid_data = Final_Data[Sample==3,]

## Checking the Selection %

table(train_data$SELECTED_FLAG)   #45.48%
table(test_data$SELECTED_FLAG)   #45.29%
table(valid_data$SELECTED_FLAG)   #45.39%

###########################
## Removing Extra SELECTED_FLAG column from train Data

train_data$SELECTED_FLAG.1 = NULL
test_data$SELECTED_FLAG.1 = NULL
valid_data$SELECTED_FLAG.1 = NULL


train_data$PAID_DATE_MONTH = as.factor(train_data$PAID_DATE_MONTH)
test_data$PAID_DATE_MONTH = as.factor(test_data$PAID_DATE_MONTH)
valid_data$PAID_DATE_MONTH = as.factor(valid_data$PAID_DATE_MONTH)

#####################################

####Data PreProcessing (numeric columns of train_data)

##Separating out Numeric columns from train data

library(dplyr)

train_num = select_if(train_data, is.numeric)

##PreProcessing numeric data

preObj <- preProcess(train_num, method= "scale")
train_num_process <- predict(preObj, train_num)

###########
### Combining the processed data to train_data

col_drop = colnames(train_num)

train_data = data.table(train_data)

train_data = train_data[, c(col_drop) := NULL]

## Combining the PreProcessed data to train_data

train_data = cbind(train_data,train_num_process)

### Removing the SRC_CLAIM_NBR from train_data

train_data$SRC_CLAIM_NBR = NULL

####################################################
####################################################
####################################################

### Model Building

train_data = data.frame(train_data)

model_Tune = tuneRF(train_data[ ,-3], train_data[ ,3], 
                    mtryStart = 3, ntreeTry = 300,
                    trace = TRUE, improve = 0.3, nodesize = 500,
                    importance = TRUE, do.trace  =TRUE, stepFactor = 2,
                    plot = TRUE, doBest=TRUE)



RF_v1 = randomForest(train_data$SELECTED_FLAG ~ . , importance = TRUE, data = train_data, ntree = 150, mtry = 11, nodesize = 500, replace = TRUE  )




RF_v2 = randomForest(train_data$SELECTED_FLAG ~ . , importance = TRUE, data = train_data, ntree = 300, mtry = 10, nodesize = 500, replace = TRUE  )

########################################
#### Predicting on test_data

##Separating numeric columns from test_data


test_num = select_if(test_data, is.numeric)

##PreProcessing numeric data

test_num_process <- predict(preObj, test_num)

###########
### Combining the processed data to test_data

col_drop = colnames(test_num)

test_data = data.table(test_data)

test_data = test_data[, c(col_drop) := NULL]

## Combining the PreProcessed data to test_data

test_data = cbind(test_data,test_num_process)

##################
### Predicting on the test data

##RF_v1

pred_1 = predict(RF_v1, test_data, type='prob')
pred_2 = ifelse(pred_1[,2]>=0.5,1, 0)
pred_3 = as.factor(pred_2)
confusionMatrix(pred_3, as.factor(as.character(test_data$SELECTED_FLAG)), positive = '1')



##RF_v2

pred_1 = predict(RF_v2, test_data, type='prob')
pred_2 = ifelse(pred_1[,2]>=0.5,1, 0)
pred_3 = as.factor(pred_2)
confusionMatrix(pred_3, as.factor(as.character(test_data$SELECTED_FLAG)), positive = '1')


