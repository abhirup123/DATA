
#################################
## setting work directory

setwd("U:/Selection Model (APC)")

##################################
###Loading the sample data

load("U:/Selection Model (APC)/1 Base_Shortlisted.RData")

#################################

Model_Data_1 = Sample_1
Model_Data_1

## Data to be kept in the modelling exercise

Model_Data_1 = subset(Sample_1, select = -c(CAMPUS_UNIT,
                                            PRIMARY_DIAG_CD,
                                            PROV_TAX_ID,
                                            SRC_PROVIDER_ID
                                            ))

###################################

## Imputing the CHECK_SERV_DIFF column value with median value

median(Model_Data_1[ which(Model_Data_1$SELECTED_FLAG==1), 'CHECK_SERV_DIFF'], na.rm = TRUE) #37
median(Model_Data_1[ which(Model_Data_1$SELECTED_FLAG==0), 'CHECK_SERV_DIFF'], na.rm = TRUE) #15

Model_Data_1[which(Model_Data_1$SELECTED_FLAG==0 & is.na(Model_Data_1$CHECK_SERV_DIFF)), 'CHECK_SERV_DIFF']=15
Model_Data_1[which(Model_Data_1$SELECTED_FLAG==1 & is.na(Model_Data_1$CHECK_SERV_DIFF)), 'CHECK_SERV_DIFF']=37


## Replacing NULLs in CLIENT_NBR with MISSING

Model_Data_1$CLIENT_NBR[is.na(Model_Data_1$CLIENT_NBR)]='MISSING'

## Replacing minority SERV_STATE_CD with 'OTHERS'


Model_Data_1$SERV_STATE_CD[which(Model_Data_1$SERV_STATE_CD %in% c('ME',	'OR',	'MA',	'KS',	'NH',	'DE',	'NM',	'SD',	'ND',	'NE',	'NJ',	'PR',	'NV',	'ID',	'HI',	'CT',	'VT',	'WY',	'AK',	'DC',	'RI'))]='OTHERS'


### Encoding of the categorical data

## Separating the categorical data from the sample data

library(data.table)

Model_Data_1 = data.table(Model_Data_1)

colnames(Model_Data_1)

Num_Cols = Model_Data_1[ , .SD, .SDcols = is.numeric]
char_cols = Model_Data_1[ , .SD, .SDcols = is.character]

colnames(char_cols)

##########
### ADMIT_TYPE_CD, POT_CD are in Num_Cols

Fact_cols = cbind(char_cols, Model_Data_1[,c( 'SRC_CLAIM_NBR','ADMIT_TYPE_CD','POT_CD') ])


###### Removing the categorical variables from the Numeric data

Num_Cols[ , c(  'ADMIT_TYPE_CD',  'POT_CD'):= NULL]


### Getting the NULL %age for each column in Fact_cols table

x = sapply(Fact_cols, function(x) sum(is.na(x)))/length(Fact_cols$SRC_CLAIM_NBR)*100

View(x)

########################
### 6 Cols have NULL values
#CAUSE_CD
#ADMIT_TYPE_CD
#BILL_TYPE_CD
#ADMIT_SRC_CD
#SRC_PAR_CD
#SRC_NTWK_ID

#################################


#### Getting claims' distribution for various categorical variables 

Fact_cols = data.table(Fact_cols)

Fact_cols = cbind(Fact_cols, Num_Cols$SELECTED_FLAG)

setnames(Fact_cols, 'V2', 'SELECTED_FLAG')

#################################
### Function to copy data on clipboard

write_to_excel <- function(x,row.names=FALSE,col.names=TRUE,...) {
  write.table(x,"clipboard",sep="\t",row.names=row.names,col.names=col.names,...)
}


############################
##Clubbing the minority class of Categorical variables into 'OTHERS'
############################

##1 ADMIT_TYPE_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = ADMIT_TYPE_CD]

write_to_excel(Claim_Cnt)

#####################################
### Replacing NULL values with 'MISSING' for ADMIT_TYPE_CD (8.4%)

Fact_cols$ADMIT_TYPE_CD[which(is.na(Fact_cols$ADMIT_TYPE_CD))] = 'MISSING'

###### Replacing minor level+NULLS ADMIT_TYPE_CD with 'OTHERS' 

z = as.character(Fact_cols$ADMIT_TYPE_CD)
ADMIT_TYPE_CD = ifelse(z %in% c('3','9', '1', 'MISSING'), z, 'OTHERS')

table(ADMIT_TYPE_CD)

#################################
##2 ADMIT_SRC_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = ADMIT_SRC_CD]

write_to_excel(Claim_Cnt)

### Converting NAs to 'MISSING'

Fact_cols$ADMIT_SRC_CD[which(is.na(Fact_cols$ADMIT_SRC_CD))] = 'MISSING'

###### Replacing minor level+NULLS ADMIT_TYPE_CD with 'OTHERS' 

z = as.character(Fact_cols$ADMIT_SRC_CD)
ADMIT_SRC_CD = ifelse(z %in% c('MISSING', '1', '2', '4'), z, 'OTHERS')

table(ADMIT_SRC_CD)

#############################
##3 BILL_TYPE_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = BILL_TYPE_CD]

write_to_excel(Claim_Cnt)

##  BILL_TYPE_CD replacing NULLS with MISSING factor

Fact_cols$BILL_TYPE_CD[which(is.na(Fact_cols$BILL_TYPE_CD))] = 'MISSING'

###### Replacing minor level+NULLS BILL_TYPE_CD with 'OTHERS' 
z = as.character(Fact_cols$BILL_TYPE_CD)
BILL_TYPE_CD = ifelse(z %in% c('131',	'133',	'329', 'MISSING', '831'), z, 'OTHERS')

table(BILL_TYPE_CD)

#############################
##4 SRC_PAR_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SRC_PAR_CD]

write_to_excel(Claim_Cnt)


###### Replacing minor level+NULLS SRC_PAR_CD with 'OTHERS' 

z = as.character(Fact_cols$SRC_PAR_CD)
SRC_PAR_CD = ifelse(z %in% c('P',	'L',	'X', '5'), z, 'OTHERS')

table(SRC_PAR_CD)

#############################
##5 CLIENT_NBR

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = CLIENT_NBR]

write_to_excel(Claim_Cnt)

### There are no other value than 56, 57, 58 & MISSING

z = as.character(Fact_cols$CLIENT_NBR)
CLIENT_NBR = z

table(CLIENT_NBR)

#############################
#############################
##6 PRIMARY_LEVEL1

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = PRIMARY_LEVEL_1]

write_to_excel(Claim_Cnt)

z = data.frame(as.character(Fact_cols$PRIMARY_LEVEL_1))

z = gsub("\"", "", z$as.character.Fact_cols.PRIMARY_LEVEL_1.)

###### Replacing minor level+NULLS  (any level less than 3000 #claims )


PRIMARY_LEVEL_1 = ifelse(z %in% c('Encounters for other specific health care',
                            'Osteoarthritis',
                            'Other dorsopathies',
                            'Other joint disorders',
                            'Spondylopathies',
                            'Diabetes mellitus',
                            'Symptoms and signs involving the circulatory and respiratory systems',
                            'Symptoms and signs involving the digestive system and abdomen',
                            'Other soft tissue disorders',
                            'General symptoms and signs',
                            'Hypertensive diseases',
                            'Chronic lower respiratory diseases',
                            'Other diseases of the urinary system',
                            'Other disorders of the skin and subcutaneous tissue',
                            'Episodic and paroxysmal disorders',
                            'Malignant neoplasms of respiratory and intrathoracic organs',
                            'Diseases of veins, lymphatic vessels and lymph nodes, not elsewhere classified',
                            'Malignant neoplasms of lymphoid, hematopoietic and related tissue',
                            'Malignant neoplasms of breast',
                            'Persons encountering health services for examinations',
                            'Complications of surgical and medical care, not elsewhere classified',
                            'Cerebrovascular diseases',
                            'Other forms of heart disease',
                            'Injuries to the knee and lower leg',
                            'Injuries to the head',
                            'Other disorders of the nervous system',
                            'Malignant neoplasms of digestive organs',
                            'Urolithiasis',
                            'Malignant neoplasms of urinary tract',
                            'Symptoms and signs involving cognition, perception, emotional state and behavior',
                            'Persons with potential health hazards related to family and personal history and certain conditions influencing health status',
                            'Inflammatory polyarthropathies',
                            'Injuries to the shoulder and upper arm',
                            'Injuries to the elbow and forearm',
                            'Other diseases of intestines',
                            'Abnormal findings on diagnostic imaging and in function studies, without diagnosis',
                            'Symptoms and signs involving the nervous and musculoskeletal systems',
                            'Disorders of bone density and structure',
                            'Metabolic disorders',
                            'Acute kidney failure and chronic kidney disease',
                            'Infections of the skin and subcutaneous tissue',
                            'Renal tubulo-interstitial diseases',
                            'Noninfective enteritis and colitis',
                            'Nutritional anemias',
                            'Melanoma and other malignant neoplasms of skin',
                            'Demyelinating diseases of the central nervous system'), z, 'OTHERS')

table(PRIMARY_LEVEL_1)

#########################################################
## 7 STD_HIPAA_PROV_SPEC_CD


Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = STD_HIPAA_PROV_SPEC_CD]

write_to_excel(Claim_Cnt)


###### Replacing minor level Cause_cd with 'OTHERS' 

z = as.character(Fact_cols$STD_HIPAA_PROV_SPEC_CD)

STD_HIPAA_PROV_SPEC_CD = ifelse(z %in% c('9999999999',
                            '282N00000X',
                            '251E00000X',
                            '314000000X',
                            '208600000X'), z, 'OTHERS')

table(STD_HIPAA_PROV_SPEC_CD)

################################
### 8 SERV_CAT_TYPE_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SERV_CAT_TYPE_CD]

write_to_excel(Claim_Cnt)


### Removing this column as 98.7% is 'T06'

Fact_cols$SERV_CAT_TYPE_CD  =NULL

######################################

### 9 SRC_NWTK_ID

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SRC_NTWK_ID]

write_to_excel(Claim_Cnt)


######### 

z = as.character(Fact_cols$SRC_NTWK_ID)
SRC_NTWK_ID = ifelse(z %in% c('5241H3I',	'0000H32',	'7030H3I',	'5331H32',	'7034H3I',	'5321H32',	'7033H3I',	'5329H3I',	'5317H3I',	'5367H3I',	'7038H32',	'7037H32',	'7039H32',	'5040H93',	'5366H32',	'0000H62'), z, 'OTHERS')

table(SRC_NTWK_ID)

#########################################
### 10 POT_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = POT_CD]

write_to_excel(Claim_Cnt)

z = as.character(Fact_cols$POT_CD)
POT_CD = ifelse(z %in% c('22', '23', '24', '12'), z, 'OTHERS')

table(POT_CD)

#########################################
### 11 CAUSE_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = CAUSE_CD]

write_to_excel(Claim_Cnt)

### Replacing NAs with MISSING values

Fact_cols$CAUSE_CD[which(is.na(Fact_cols$CAUSE_CD))] = 'MISSING'


z = as.character(Fact_cols$CAUSE_CD)
CAUSE_CD = ifelse(z %in% c('001', '002', 'MISSING'), z, 'OTHERS')

table(CAUSE_CD)

#########################################
### 12 CLM_BENEFIT_PAR_CAT_CD

# There are only 2 values N & P, hence keeping it as is


#########################################
### 13 SRC_LOB_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SRC_LOB_CD]

write_to_excel(Claim_Cnt)

#################

z = as.character(Fact_cols$SRC_LOB_CD)
SRC_LOB_CD = ifelse(z %in% c('3I',	'32',	'93',	'62',	'3G',	'39' ), z, 'OTHERS')

table(SRC_LOB_CD)


#########################################
### 13 SRC_POT_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SRC_POT_CD]

write_to_excel(Claim_Cnt)

#################

z = as.character(Fact_cols$SRC_POT_CD)
SRC_POT_CD = ifelse(z %in% c('2', '4', '7', 'R', 'I', 'W' ), z, 'OTHERS')

table(SRC_LOB_CD)

############################

##14 PRIMARY_LEVEL_2

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = PRIMARY_LEVEL_2]

write_to_excel(Claim_Cnt)

z = data.frame(as.character(Fact_cols$PRIMARY_LEVEL_2))

z = gsub("\"", "", z$as.character.Fact_cols.PRIMARY_LEVEL_2.)

###### Replacing minor level+NULLS  (any level less than 3000 #claims )


PRIMARY_LEVEL_2 = ifelse(z %in% c('Diseases of the musculoskeletal system and connective tissue',
                                  'Factors influencing health status and contact with health services',
                                  'Neoplasms',
                                  'Symptoms, signs and abnormal clinical and laboratory findings, not elsewhere classified',
                                  'Injury, poisoning and certain other consequences of external causes',
                                  'Diseases of the circulatory system',
                                  'Diseases of the genitourinary system',
                                  'Diseases of the nervous system',
                                  'Endocrine, nutritional and metabolic diseases',
                                  'Diseases of the respiratory system',
                                  'Diseases of the digestive system',
                                  'Diseases of the skin and subcutaneous tissue',
                                  'Diseases of the blood and blood-forming organs and certain disorders involving the immune mechanism',
                                  'Mental, Behavioral and Neurodevelopmental disorders',
                                  'Diseases of the eye and adnexa',
                                  'Certain infectious and parasitic diseases'), z,  'OTHERS' )


table(PRIMARY_LEVEL_2)

########################


#########################################################

### Cbind the above categorical variables

Comb_Fact_Data = data.frame(cbind( ADMIT_SRC_CD, ADMIT_TYPE_CD, BILL_TYPE_CD, CAUSE_CD, CLIENT_NBR, POT_CD, PRIMARY_LEVEL_1, PRIMARY_LEVEL_2, SRC_LOB_CD, SRC_NTWK_ID, SRC_PAR_CD, SRC_POT_CD, STD_HIPAA_PROV_SPEC_CD ))

colnames(Comb_Fact_Data)

######## Removing the above cols from the Fact_cols data

Fact_cols[ ,c(	'ADMIT_SRC_CD', 'ADMIT_TYPE_CD', 'BILL_TYPE_CD', 'CAUSE_CD', 'CLIENT_NBR', 'POT_CD', 'PRIMARY_LEVEL_1', 'PRIMARY_LEVEL_2', 'SRC_LOB_CD', 'SRC_NTWK_ID', 'SRC_PAR_CD', 'SRC_POT_CD', 'STD_HIPAA_PROV_SPEC_CD'  )] = NULL


##### Adding the revised dataset to the Fact_cols table

Fact_cols = cbind(Fact_cols, Comb_Fact_Data)

######################
## Removing the unwanted datasets

rm(Claim_Cnt,ADMIT_SRC_CD, ADMIT_TYPE_CD, BILL_TYPE_CD, CAUSE_CD, CLIENT_NBR, POT_CD, PRIMARY_LEVEL_1, PRIMARY_LEVEL_2, SRC_LOB_CD, SRC_NTWK_ID, SRC_PAR_CD, SRC_POT_CD, STD_HIPAA_PROV_SPEC_CD ,x, z)

###########################

#####################################################
## Creating CHECK_DATE_MONTH column
library(lubridate)

CHECK_DATE_MONTH = data.frame(month(as.POSIXlt(Model_Data_1$CHECK_DATE, format="%d/%m/%Y")))

## Renaming the column name to CHECK_DATE_MONTH

colnames(CHECK_DATE_MONTH) = 'CHECK_DATE_MONTH'

## Replacing the NULL values in CHECK_DATE_MONTH to MISSING

CHECK_DATE_MONTH$CHECK_DATE_MONTH[which(is.na(CHECK_DATE_MONTH$CHECK_DATE_MONTH))] = 'MISSING'

#### Combining the CHECK_DATE_MONTH to Fact_Cols data

Fact_cols = cbind(Fact_cols, CHECK_DATE_MONTH)

############################################
############################################
############################################
############################################

colnames(Num_Cols)


### Extracting month from PAID_DATE in Num_Cols

Num_Cols$PAID_DATE_MONTH = substr(Num_Cols$PAID_DATE, 5,6)

#############################

# Combining the Num_Cols and Fact_cols

Final_Data = cbind(Fact_cols, Num_Cols)


###################################
## Removing the duplicated rows

Final_Data = Final_Data[!duplicated(Final_Data), ]

############################
### Changing the data type of variables in the Final data

## Remove the PAID_DATE 

Final_Data$PAID_DATE = NULL
Final_Data$USE_INDICATOR = NULL
Final_Data$SHORTLISTED_BY = NULL

## Removing the SRC_CLAIM_NBR (there are 2 Claim_Nbrs column)
Final_Data[, 3 := NULL]



## Changing the variables to Factor

cols = c('CLM_BENEFIT_PAR_CAT_CD',	'SERV_STATE_CD',	'SELECTED_FLAG',	'ADMIT_SRC_CD',	'ADMIT_TYPE_CD',	'BILL_TYPE_CD',	'CAUSE_CD',	'CLIENT_NBR',	'POT_CD',	'PRIMARY_LEVEL_1',	'PRIMARY_LEVEL_2',	'SRC_LOB_CD',	'SRC_NTWK_ID',	'SRC_PAR_CD',	'SRC_POT_CD',	'STD_HIPAA_PROV_SPEC_CD',	'CHECK_DATE_MONTH',		'REV_0450',	'REV_0260',	'REV_0320',	'REV_0420',	'REV_0636',	'REV_0324',	'REV_0352',	'REV_0424',	'REV_0360',	'REV_0350',	'REV_0351',	'REV_0335',	'REV_0761',	'REV_0490',	'REV_0430',	'REV_0510',	'REV_0361',	'REV_0434',	'REV_0551',	'REV_OTHER',	'SELECTED_FLAG',	'PAID_DATE_MONTH')


## Multile methods gave error so changing the column data type individually

Final_Data$CLM_BENEFIT_PAR_CAT_CD = as.factor(Final_Data$CLM_BENEFIT_PAR_CAT_CD)
Final_Data$SERV_STATE_CD = as.factor(Final_Data$SERV_STATE_CD)
Final_Data$SELECTED_FLAG = as.factor(Final_Data$SELECTED_FLAG)
Final_Data$ADMIT_SRC_CD = as.factor(Final_Data$ADMIT_SRC_CD)
Final_Data$ADMIT_TYPE_CD = as.factor(Final_Data$ADMIT_TYPE_CD)
Final_Data$BILL_TYPE_CD = as.factor(Final_Data$BILL_TYPE_CD)
Final_Data$CAUSE_CD = as.factor(Final_Data$CAUSE_CD)
Final_Data$CLIENT_NBR = as.factor(Final_Data$CLIENT_NBR)
Final_Data$POT_CD = as.factor(Final_Data$POT_CD)
Final_Data$PRIMARY_LEVEL_1 = as.factor(Final_Data$PRIMARY_LEVEL_1)
Final_Data$PRIMARY_LEVEL_2 = as.factor(Final_Data$PRIMARY_LEVEL_2)
Final_Data$SRC_LOB_CD = as.factor(Final_Data$SRC_LOB_CD)
Final_Data$SRC_NTWK_ID = as.factor(Final_Data$SRC_NTWK_ID)
Final_Data$SRC_PAR_CD = as.factor(Final_Data$SRC_PAR_CD)
Final_Data$SRC_POT_CD = as.factor(Final_Data$SRC_POT_CD)
Final_Data$STD_HIPAA_PROV_SPEC_CD = as.factor(Final_Data$STD_HIPAA_PROV_SPEC_CD)
Final_Data$CHECK_DATE_MONTH = as.factor(Final_Data$CHECK_DATE_MONTH)
Final_Data$SRC_CLAIM_NBR = as.factor(Final_Data$SRC_CLAIM_NBR)
Final_Data$REV_0450 = as.factor(Final_Data$REV_0450)
Final_Data$REV_0260 = as.factor(Final_Data$REV_0260)
Final_Data$REV_0320 = as.factor(Final_Data$REV_0320)
Final_Data$REV_0420 = as.factor(Final_Data$REV_0420)
Final_Data$REV_0636 = as.factor(Final_Data$REV_0636)
Final_Data$REV_0324 = as.factor(Final_Data$REV_0324)
Final_Data$REV_0352 = as.factor(Final_Data$REV_0352)
Final_Data$REV_0424 = as.factor(Final_Data$REV_0424)
Final_Data$REV_0360 = as.factor(Final_Data$REV_0360)
Final_Data$REV_0350 = as.factor(Final_Data$REV_0350)
Final_Data$REV_0351 = as.factor(Final_Data$REV_0351)
Final_Data$REV_0335 = as.factor(Final_Data$REV_0335)
Final_Data$REV_0761 = as.factor(Final_Data$REV_0761)
Final_Data$REV_0490 = as.factor(Final_Data$REV_0490)
Final_Data$REV_0430 = as.factor(Final_Data$REV_0430)
Final_Data$REV_0510 = as.factor(Final_Data$REV_0510)
Final_Data$REV_0361 = as.factor(Final_Data$REV_0361)
Final_Data$REV_0434 = as.factor(Final_Data$REV_0434)
Final_Data$REV_0551 = as.factor(Final_Data$REV_0551)
Final_Data$REV_OTHER = as.factor(Final_Data$REV_OTHER)

####Changing to NUMERIC Datatype

Final_Data$MBR_AGE = as.numeric(Final_Data$MBR_AGE)
Final_Data$CHECK_SERV_DIFF = as.numeric(Final_Data$CHECK_SERV_DIFF)
Final_Data$DIAG_CNT = as.numeric(Final_Data$DIAG_CNT)
Final_Data$MOD_CNT = as.numeric(Final_Data$MOD_CNT)
Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_NET_PAID_AMT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_NET_PAID_AMT)
Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_NET_PAID_AMT = as.numeric(Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_NET_PAID_AMT)
Final_Data$SURGERY_URINARY_SYSTEM_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_URINARY_SYSTEM_NET_PAID_AMT)
Final_Data$SURGERY_RESPIRATORY_SYSTEM_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_RESPIRATORY_SYSTEM_NET_PAID_AMT)
Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_NET_PAID_AMT = as.numeric(Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_NET_PAID_AMT)
Final_Data$TEMPORARY_CODES_NET_PAID_AMT = as.numeric(Final_Data$TEMPORARY_CODES_NET_PAID_AMT)
Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_NET_PAID_AMT)
Final_Data$CHEMOTHERAPY_DRUGS_NET_PAID_AMT = as.numeric(Final_Data$CHEMOTHERAPY_DRUGS_NET_PAID_AMT)
Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_NET_PAID_AMT = as.numeric(Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_NET_PAID_AMT)
Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_NET_PAID_AMT = as.numeric(Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_NET_PAID_AMT)
Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_NET_PAID_AMT = as.numeric(Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_NET_PAID_AMT)
Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_NET_PAID_AMT = as.numeric(Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_NET_PAID_AMT)
Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_NET_PAID_AMT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_NET_PAID_AMT)
Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_NET_PAID_AMT)
Final_Data$SURGERY_NERVOUS_SYSTEM_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_NERVOUS_SYSTEM_NET_PAID_AMT)
Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_ALLOW_XCOB_AMT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_ALLOW_XCOB_AMT)
Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_ALLOW_XCOB_AMT = as.numeric(Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_ALLOW_XCOB_AMT)
Final_Data$SURGERY_URINARY_SYSTEM_ALLOW_XCOB_AMT = as.numeric(Final_Data$SURGERY_URINARY_SYSTEM_ALLOW_XCOB_AMT)
Final_Data$SURGERY_RESPIRATORY_SYSTEM_ALLOW_XCOB_AMT = as.numeric(Final_Data$SURGERY_RESPIRATORY_SYSTEM_ALLOW_XCOB_AMT)
Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_ALLOW_XCOB_AMT = as.numeric(Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_ALLOW_XCOB_AMT)
Final_Data$TEMPORARY_CODES_ALLOW_XCOB_AMT = as.numeric(Final_Data$TEMPORARY_CODES_ALLOW_XCOB_AMT)
Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_ALLOW_XCOB_AMT = as.numeric(Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_ALLOW_XCOB_AMT)
Final_Data$CHEMOTHERAPY_DRUGS_ALLOW_XCOB_AMT = as.numeric(Final_Data$CHEMOTHERAPY_DRUGS_ALLOW_XCOB_AMT)
Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_ALLOW_XCOB_AMT = as.numeric(Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_ALLOW_XCOB_AMT)
Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_ALLOW_XCOB_AMT = as.numeric(Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_ALLOW_XCOB_AMT)
Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_ALLOW_XCOB_AMT = as.numeric(Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_ALLOW_XCOB_AMT)
Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_ALLOW_XCOB_AMT = as.numeric(Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_ALLOW_XCOB_AMT)
Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_ALLOW_XCOB_AMT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_ALLOW_XCOB_AMT)
Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_ALLOW_XCOB_AMT = as.numeric(Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_ALLOW_XCOB_AMT)
Final_Data$SURGERY_NERVOUS_SYSTEM_ALLOW_XCOB_AMT = as.numeric(Final_Data$SURGERY_NERVOUS_SYSTEM_ALLOW_XCOB_AMT)
Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_PAID_AMT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_PAID_AMT)
Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_PAID_AMT = as.numeric(Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_PAID_AMT)
Final_Data$SURGERY_URINARY_SYSTEM_PAID_AMT = as.numeric(Final_Data$SURGERY_URINARY_SYSTEM_PAID_AMT)
Final_Data$SURGERY_RESPIRATORY_SYSTEM_PAID_AMT = as.numeric(Final_Data$SURGERY_RESPIRATORY_SYSTEM_PAID_AMT)
Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_PAID_AMT = as.numeric(Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_PAID_AMT)
Final_Data$TEMPORARY_CODES_PAID_AMT = as.numeric(Final_Data$TEMPORARY_CODES_PAID_AMT)
Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_PAID_AMT = as.numeric(Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_PAID_AMT)
Final_Data$CHEMOTHERAPY_DRUGS_PAID_AMT = as.numeric(Final_Data$CHEMOTHERAPY_DRUGS_PAID_AMT)
Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_PAID_AMT = as.numeric(Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_PAID_AMT)
Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_PAID_AMT = as.numeric(Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_PAID_AMT)
Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_PAID_AMT = as.numeric(Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_PAID_AMT)
Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_PAID_AMT = as.numeric(Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_PAID_AMT)
Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_PAID_AMT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_PAID_AMT)
Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_PAID_AMT = as.numeric(Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_PAID_AMT)
Final_Data$SURGERY_NERVOUS_SYSTEM_PAID_AMT = as.numeric(Final_Data$SURGERY_NERVOUS_SYSTEM_PAID_AMT)
Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$SURGERY_URINARY_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_URINARY_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$SURGERY_RESPIRATORY_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_RESPIRATORY_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$TEMPORARY_CODES_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$TEMPORARY_CODES_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$CHEMOTHERAPY_DRUGS_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$CHEMOTHERAPY_DRUGS_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$SURGERY_NERVOUS_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT = as.numeric(Final_Data$SURGERY_NERVOUS_SYSTEM_CTRCT_ALLOC_NET_PAID_AMT)
Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_SERV_UNIT_CNT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_EMERGENCY_DEPARTMENT_SERVICES_SERV_UNIT_CNT)
Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_SERV_UNIT_CNT = as.numeric(Final_Data$DRUGS_ADMINISTERED_OTHER_THAN_ORAL_METHOD_SERV_UNIT_CNT)
Final_Data$SURGERY_URINARY_SYSTEM_SERV_UNIT_CNT = as.numeric(Final_Data$SURGERY_URINARY_SYSTEM_SERV_UNIT_CNT)
Final_Data$SURGERY_RESPIRATORY_SYSTEM_SERV_UNIT_CNT = as.numeric(Final_Data$SURGERY_RESPIRATORY_SYSTEM_SERV_UNIT_CNT)
Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_SERV_UNIT_CNT = as.numeric(Final_Data$MEDICINE_HYDRATION_THERAPEUTIC_PROPHYLACTIC_DIAGNOSTIC_INJECTIONS_AND_INFUSIONS_AND_CHEMOTHERAPY_SERV_UNIT_CNT)
Final_Data$TEMPORARY_CODES_SERV_UNIT_CNT = as.numeric(Final_Data$TEMPORARY_CODES_SERV_UNIT_CNT)
Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_SERV_UNIT_CNT = as.numeric(Final_Data$SURGERY_INTEGUMENTARY_SYSTEM_SERV_UNIT_CNT)
Final_Data$CHEMOTHERAPY_DRUGS_SERV_UNIT_CNT = as.numeric(Final_Data$CHEMOTHERAPY_DRUGS_SERV_UNIT_CNT)
Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_SERV_UNIT_CNT = as.numeric(Final_Data$MEDICINE_NEUROLOGY_AND_NEUROMUSCULAR_PROCEDURES_SERV_UNIT_CNT)
Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_SERV_UNIT_CNT = as.numeric(Final_Data$PATHOLOGY_AND_LABORATORY_SERVICES_SERV_UNIT_CNT)
Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_SERV_UNIT_CNT = as.numeric(Final_Data$MEDICINE_PHYSICAL_MEDICINE_AND_REHABILITATION_SERV_UNIT_CNT)
Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_SERV_UNIT_CNT = as.numeric(Final_Data$RADIOLOGY_DIAGNOSTIC_RADIOLOGY_SERV_UNIT_CNT)
Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_SERV_UNIT_CNT = as.numeric(Final_Data$EVALUATION_AND_MANAGEMENT_CRITICAL_CARE_SERVICES_SERV_UNIT_CNT)
Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_SERV_UNIT_CNT = as.numeric(Final_Data$SURGERY_MUSCULOSKELETAL_SYSTEM_SERV_UNIT_CNT)
Final_Data$SURGERY_NERVOUS_SYSTEM_SERV_UNIT_CNT = as.numeric(Final_Data$SURGERY_NERVOUS_SYSTEM_SERV_UNIT_CNT)


#####################
### Saving the dataset


save(Final_Data, file = 'Model_RAW_Data.RData')
save.image("Data_Transformation.RData")
