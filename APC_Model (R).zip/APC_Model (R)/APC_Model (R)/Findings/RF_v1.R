### Setting work directory

setwd("U:/APC_Model (R)/Findings")

#########################
###Loading the data

load("Final_Data_RF.RData")

#####################
### Loading required libraries

library(randomForest)
library(dplyr)
library(caret)
library(e1071)
library(data.table)

#########################

a = sapply(Data_Final, function(x) length(unique(x)))
View(a)


## Removing the unrequired columns

Final_Data = Data_Final


Final_Data = subset(Final_Data, select  = -c(CPT_MOD_CD2, CPT_MOD_CD, CPT_BUCKET, FIND_FLAG.x, PRIMARY_DIAG_CD_LEVEL1) )

setnames(Final_Data, 'FIND_FLAG.y', 'FIND_FLAG')

###########
### Replacing NULLS in Prov_Hit_Rate to 0

Final_Data$PROV_HIT_RATE[ which(is.na(Final_Data$PROV_HIT_RATE))]=0

#############################################
### Changing character columns to factor

a = colnames(Final_Data)
View(a)

num_cols = c('MBR_AGE',	'DIAG_CNT',	'NET_PAID_AMT',	'SERV_UNIT_CNT',	'MOD_CNT',	'PROV_HIT_RATE')

fact_cols = setdiff(names(Final_Data), num_cols)

Final_Data[fact_cols] <- lapply(Final_Data[fact_cols], factor) 


#########################################
### train and test

Sample = sample(3, nrow(Final_Data), replace = TRUE, prob = c(0.6,0.2, 0.2))
train_data = Final_Data[Sample==1,]
test_data = Final_Data[Sample==2,]
valid_data = Final_Data[Sample==3,]


### Checking FIND_FLAG %
prop.table(table(train_data$FIND_FLAG))   #13.29%
prop.table(table(test_data$FIND_FLAG))   #13.07%
prop.table(table(valid_data$FIND_FLAG))   #13.47%


### Model Tuning for best mTry

train_data$SRC_CLAIM_NBR = NULL

model_Tune = tuneRF(train_data[ ,-110], train_data[ , 110], 
                    mtryStart = 3, ntreeTry = 100, trace = TRUE,
                    replace = TRUE, importance = TRUE, nodesize = 500,
                    improve = 0.05, plot = TRUE, doBest=TRUE)


summary(model_Tune)
print(model_Tune)


model_Tune_over_sample = tuneRF(over_sample[ ,-110], over_sample[ , 110], 
                    mtryStart = 3, ntreeTry = 100, trace = TRUE,
                    replace = TRUE, importance = TRUE, nodesize = 700,
                    improve = 0.05, plot = TRUE, doBest=TRUE)


summary(model_Tune_over_sample)
print(model_Tune_over_sample)


save.image("RF_v1.RData")

## Predicting on the test data

pred_1 = predict(model_Tune, test_data, type = 'prob')
pred_1 = as.data.frame(pred_1)
pred_2 = ifelse(pred_1[,2]>=0.05,1, 0)
pred_3 = as.factor(pred_2)
confusionMatrix(pred_3, test_data$FIND_FLAG, positive = '1')

write.csv(cbind(pred_1, test_data[ , c('SRC_CLAIM_NBR', 'FIND_FLAG')]), "Test_Data_RF_v1.csv")


## Predicting on the valid data

pred_1 = predict(model_Tune, valid_data, type = 'prob')
pred_1 = as.data.frame(pred_1)
pred_2 = ifelse(pred_1[,2]>=0.05,1, 0)
pred_3 = as.factor(pred_2)
confusionMatrix(pred_3, valid_data$FIND_FLAG, positive = '1')

write.csv(cbind(pred_1, valid_data[ , c('SRC_CLAIM_NBR', 'FIND_FLAG')]), "Valid_Data_RF_v1.csv")



## On train data

pred_1 = predict(model_Tune, train_data, type = 'prob')
pred_1 = as.data.frame(pred_1)
pred_2 = ifelse(pred_1[,2]>=0.05,1, 0)
pred_3 = as.factor(pred_2)
confusionMatrix(pred_3, train_data$FIND_FLAG, positive = '1')


write.csv(cbind(pred_1, train_data[ , c( 'FIND_FLAG')]), "Train_Data_RF_v1.csv")

##########################################
##########################################


RF_try = randomForest(FIND_FLAG~., over_sample, 
                    mtry = 26, ntree = 100, importance = TRUE, nodesize = 500)

## Predicting on the test data

pred_1 = predict(RF_try, test_data, type = 'prob')
pred_1 = as.data.frame(pred_1)
pred_2 = ifelse(pred_1[,2]>=0.05,1, 0)
pred_3 = as.factor(pred_2)
confusionMatrix(pred_3, test_data$FIND_FLAG, positive = '1')




## Predicting on the valid data

pred_1 = predict(RF_try, valid_data, type = 'prob')
pred_1 = as.data.frame(pred_1)
pred_2 = ifelse(pred_1[,2]>=0.05,1, 0)
pred_3 = as.factor(pred_2)
confusionMatrix(pred_3, valid_data$FIND_FLAG, positive = '1')

## On train data

pred_1 = predict(RF_try, train_data, type = 'prob')
pred_1 = as.data.frame(pred_1)
pred_2 = ifelse(pred_1[,2]>=0.05,1, 0)
pred_3 = as.factor(pred_2)
confusionMatrix(pred_3, train_data$FIND_FLAG, positive = '1')

##########################################
##########################################
## Variable Importance


imp = importance(RF_try)
imp = data.frame(imp)

write.csv(imp, "VarImp.csv", row.names = TRUE)
