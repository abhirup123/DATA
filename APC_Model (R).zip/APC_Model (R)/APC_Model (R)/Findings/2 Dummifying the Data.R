### Setting work directory

setwd("U:/APC_Model (R)/Findings")

#########################
###Loading the data

load("1 Findings RAW Data.RData")

############################
## Calling required libraries

library(caret)
library(data.table)
library(dplyr)



### Getting NULL values for categorical variables

colnames(Findings_Base)

## Removing unrequired columns

Findings_Base$PROV_TAX_ID = NULL
Findings_Base$EXTRACT_TYPE = NULL
Findings_Base$AUDITED_BY = NULL
Findings_Base$AUDIT_DATE = NULL
Findings_Base$CAMPUS_UNIT = NULL


#############################################

## Getting numeric/categorical columns

Findings_Base = data.table(Findings_Base)

colnames(Findings_Base)

Num_Cols = select_if(Findings_Base, is.numeric)
char_cols = select_if(Findings_Base, is.character)

colnames(char_cols)
colnames(Num_Cols)

##### categorical columns stored as numeric

  #POT_CD
  #All REV_CDs (These cols are already dummified)
  #CLIENT_NBR
  #ADMIT_TYPE_CD 
  
###Factor columns (combining the categorical variables in the Num_cols except the Rev_Cds)

Fact_cols = cbind(char_cols, Findings_Base[,c( 'SRC_CLAIM_NBR','ADMIT_TYPE_CD',  'CLIENT_NBR', 'POT_CD', 'FIND_FLAG') ])

###### Removing the categorical variables from the Numeric data

Num_Cols[ , c(  'ADMIT_TYPE_CD', 'CLIENT_NBR', 'POT_CD'):= NULL]


### Getting the NULL %age for each column in Fact_cols table

x = sapply(Fact_cols, function(x) sum(is.na(x)))/length(Fact_cols$SRC_CLAIM_NBR)*100

View(x)

####################################################


## There are 8 columns with missing values (ADMIT_TYPE_CD,	ADMIT_SRC_CD,	BILL_TYPE_CD,	CHECK_DATE_MONTH,	CAUSE_CD,	SRC_PAR_CD, SRC_NTWK_ID, LOB_TYPE)


#### Getting claims' distribution for various categorical variables 

Fact_cols = data.table(Fact_cols)


####################################################

### Function to copy data on clipboard

write_to_excel <- function(x,row.names=FALSE,col.names=TRUE,...) {
  write.table(x,"clipboard",sep="\t",row.names=row.names,col.names=col.names,...)
}


############################
##Clubbing the minority class of Categorical variables into 'OTHERS'
############################

##1 ADMIT_TYPE_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = ADMIT_TYPE_CD]


write_to_excel(Claim_Cnt)

#####################################
### Replacing NULL values with 'MISSING' for ADMIT_TYPE_CD (8.4%)

Fact_cols$ADMIT_TYPE_CD[which(is.na(Fact_cols$ADMIT_TYPE_CD))] = 'MISSING'

###### Replacing minor level+NULLS ADMIT_TYPE_CD with 'OTHERS' 

z = as.character(Fact_cols$ADMIT_TYPE_CD)
ADMIT_TYPE_CD = ifelse(z %in% c('3','9', '1', 'MISSING'), z, 'OTHERS')

table(ADMIT_TYPE_CD)

#############################
##2 ADMIT_SRC_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = ADMIT_SRC_CD]

write_to_excel(Claim_Cnt)

### Converting NAs to 'MISSING' (9.7%)


Fact_cols$ADMIT_SRC_CD[which(is.na(Fact_cols$ADMIT_SRC_CD))] = 'MISSING'


###### Replacing minor level+NULLS ADMIT_TYPE_CD with 'OTHERS' 

z = as.character(Fact_cols$ADMIT_SRC_CD)
ADMIT_SRC_CD = ifelse(z %in% c('MISSING', '1', '2', '4'), z, 'OTHERS')

table(ADMIT_SRC_CD)

#############################
##3 BILL_TYPE_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = BILL_TYPE_CD]

write_to_excel(Claim_Cnt)


Fact_cols$BILL_TYPE_CD[which(is.na(Fact_cols$BILL_TYPE_CD))] = 'MISSING'


###### Replacing minor level+NULLS BILL_TYPE_CD with 'OTHERS' 
z = as.character(Fact_cols$BILL_TYPE_CD)
BILL_TYPE_CD = ifelse(z %in% c('131',	'133',	'329', 'MISSING'), z, 'OTHERS')


table(BILL_TYPE_CD)

#############################
##4 SRC_PAR_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SRC_PAR_CD]

write_to_excel(Claim_Cnt)


###### Replacing minor level+NULLS SRC_PAR_CD with 'OTHERS' 

z = as.character(Fact_cols$SRC_PAR_CD)
SRC_PAR_CD = ifelse(z %in% c('P',	'L',	'X', '5'), z, 'OTHERS')

table(SRC_PAR_CD)

#############################
##5 CLIENT_NBR

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = CLIENT_NBR]

write_to_excel(Claim_Cnt)


###### There are no other values than 56, 57, 58

z = as.character(Fact_cols$CLIENT_NBR)
CLIENT_NBR = ifelse(z %in% c('56', '57', '58'), z, 'OTHERS')

table(CLIENT_NBR)

#############################

#############################
##6 PRIMARY_DIAG_CD_LEVEL1

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = PRIMARY_DIAG_CD_LEVEL1]

write_to_excel(Claim_Cnt)

z = data.frame(as.character(Fact_cols$PRIMARY_DIAG_CD_LEVEL1))

z = gsub("\"", "", z$as.character.Fact_cols.PRIMARY_DIAG_CD_LEVEL1.)

###### Replacing minor level+NULLS  (any level less than 600 #claims )

PRIMARY_DIAG_CD_LEVEL1 = ifelse(z %in% c('Encounters for other specific health care',
                                         'Osteoarthritis',
                                         'Diabetes mellitus',
                                         'Malignant neoplasms of breast',
                                         'Malignant neoplasms of lymphoid, hematopoietic and related tissue',
                                         'Malignant neoplasms of respiratory and intrathoracic organs',
                                         'Other disorders of the skin and subcutaneous tissue',
                                         'Chronic lower respiratory diseases',
                                         'Ischemic heart diseases',
                                         'Hypertensive diseases',
                                         'Diseases of veins, lymphatic vessels and lymph nodes, not elsewhere classified',
                                         'Complications of surgical and medical care, not elsewhere classified',
                                         'Other soft tissue disorders',
                                         'Urolithiasis',
                                         'Malignant neoplasms of urinary tract',
                                         'Injuries to the knee and lower leg',
                                         'Injuries to the elbow and forearm',
                                         'Malignant neoplasms of digestive organs',
                                         'Inflammatory polyarthropathies',
                                         'Renal tubulo-interstitial diseases',
                                         'Other forms of heart disease',
                                         'Other joint disorders',
                                         'Cerebrovascular diseases',
                                         'Other diseases of the urinary system',
                                         'Melanoma and other malignant neoplasms of skin',
                                         'Noninflammatory disorders of female genital tract',
                                         'Acute kidney failure and chronic kidney disease',
                                         'Other bacterial diseases',
                                         'Other diseases of the digestive system',
                                         'Influenza and pneumonia',
                                         'Nutritional anemias',
                                         'Episodic and paroxysmal disorders',
                                         'Diseases of esophagus, stomach and duodenum'), z, 'OTHERS')

table(PRIMARY_DIAG_CD_LEVEL1)

#########################################################
## 7 STD_HIPAA_PROV_SPEC_CD


Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = STD_HIPAA_PROV_SPEC_CD]

write_to_excel(Claim_Cnt)


###### Replacing minor level Cause_cd with 'OTHERS' 

z = as.character(Fact_cols$STD_HIPAA_PROV_SPEC_CD)

STD_HIPAA_PROV_SPEC_CD = ifelse(z %in% c('282N00000X',
                                         '9999999999',
                                         '251E00000X',
                                         '208600000X'), z, 'OTHERS')

table(STD_HIPAA_PROV_SPEC_CD)

################################
### 8 SERV_CAT_TYPE_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SERV_CAT_TYPE_CD]

write_to_excel(Claim_Cnt)


z = as.character(Fact_cols$SERV_CAT_TYPE_CD)
SERV_CAT_TYPE_CD = ifelse(z %in% c('T06', 'A01'), z, 'OTHERS')

table(SERV_CAT_TYPE_CD)

################################
### 9 SRC_NWTK_ID

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SRC_NTWK_ID]

write_to_excel(Claim_Cnt)


######### 

z = as.character(Fact_cols$SRC_NTWK_ID)
SRC_NTWK_ID = ifelse(z %in% c('5241H3I',
                              '0000H32',
                              '7030H3I',
                              '5331H32',
                              '7034H3I',
                              '5329H3I',
                              '7033H3I',
                              '5367H3I',
                              '5317H3I',
                              '5321H32',
                              '7038H32',
                              '7037H32',
                              '7039H32'), z, 'OTHERS')

table(SRC_NTWK_ID)

#########################################

### 10 POT_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = POT_CD]

write_to_excel(Claim_Cnt)

z = as.character(Fact_cols$POT_CD)
POT_CD = ifelse(z %in% c('22', '23', '24', '12'), z, 'OTHERS')

table(POT_CD)

#########################################
### 11 CAUSE_CD


Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = CAUSE_CD]

write_to_excel(Claim_Cnt)

### Replacing NAs with MISSING values

Fact_cols$CAUSE_CD[which(is.na(Fact_cols$CAUSE_CD))] = 'MISSING'


z = as.character(Fact_cols$CAUSE_CD)
CAUSE_CD = ifelse(z %in% c('001', '002', 'MISSING'), z, 'OTHERS')

table(CAUSE_CD)

#########################################
### 11 SERV_STATE_CD

Claim_Cnt = Fact_cols[, .(Claim_dist = length(unique(SRC_CLAIM_NBR))), by = SERV_STATE_CD]

write_to_excel(Claim_Cnt)

####

z = as.character(Fact_cols$SERV_STATE_CD)
SERV_STATE_CD = ifelse(z %in% c('TX',	'GA',	'IL',	'OH',	'NC',	'PA',	'MI',	'MN',	'MO',	'TN',	'WV',	'KY',	'AL',	'VA',	'MS',	'IN',	'LA',	'CO',	'NY',	'FL',	'CA',	'OK',	'WA',	'WI',	'UT',	'SC',	'MT',	'ME',	'AZ',	'AR',	'IA',	'OR',	'KS',	'DE',	'NH'), z, 'OTHERS')

table(SERV_STATE_CD)


#########################################################

### Cbind the above categorical variables

Comb_Fact_Data = data.frame(cbind( ADMIT_SRC_CD, ADMIT_TYPE_CD, BILL_TYPE_CD, CLIENT_NBR, POT_CD, PRIMARY_DIAG_CD_LEVEL1, SERV_CAT_TYPE_CD, SRC_NTWK_ID, SRC_PAR_CD, STD_HIPAA_PROV_SPEC_CD, CAUSE_CD,SERV_STATE_CD  ))

colnames(Comb_Fact_Data)


######## Removing the above cols from the Fact_cols data

Fact_cols[ ,c(	'ADMIT_SRC_CD',		'ADMIT_TYPE_CD',	'BILL_TYPE_CD', 'CLIENT_NBR',  'POT_CD','PRIMARY_DIAG_CD_LEVEL1','SERV_CAT_TYPE_CD', 'SRC_NTWK_ID','SRC_PAR_CD', 'STD_HIPAA_PROV_SPEC_CD',		'CAUSE_CD', 'SERV_STATE_CD'  )] = NULL


##### Adding the revised dataset to the Fact_cols table

Fact_cols = cbind(Fact_cols, Comb_Fact_Data)


rm(Claim_Cnt,'ADMIT_SRC_CD',		'ADMIT_TYPE_CD',	'BILL_TYPE_CD', 'CLIENT_NBR',  'POT_CD','PRIMARY_DIAG_CD_LEVEL1','SERV_CAT_TYPE_CD', 'SRC_NTWK_ID','SRC_PAR_CD', 'STD_HIPAA_PROV_SPEC_CD',	'SERV_STATE_CD',	'CAUSE_CD', 'z', 'x')

#####################################################
## Replacing the NULL values in CHECK_DATE_MONTH, CPT_MOD to MISSING

Fact_cols$CHECK_DATE_MONTH[which(is.na(Fact_cols$CHECK_DATE_MONTH))] = 'MISSING'

#####################
## one hot encoding for the fact table

Fact_cols$SRC_CLAIM_NBR = NULL
Fact_cols$FIND_FLAG = NULL



x <- dummyVars(" ~  CHECK_DATE_MONTH + ADMIT_TYPE_CD     + CPT_BUCKET+   
ADMIT_SRC_CD     +  BILL_TYPE_CD    + SRC_PAR_CD   +  CAUSE_CD +       
CLIENT_NBR   +  SERV_STATE_CD + LOB_TYPE + PRIMARY_DIAG_CD_LEVEL1+ STD_HIPAA_PROV_SPEC_CD + SERV_CAT_TYPE_CD  + SRC_NTWK_ID + POT_CD", data = Fact_cols, sep = '_')

Fact_OHE <- data.frame(predict(x, newdata = Fact_cols))

Fact_OHE = data.table(Fact_OHE)

##Combining the one hot encoded table with claim_nbr

Fact_OHE = cbind(Findings_Base[ ,c('SRC_CLAIM_NBR')], Fact_OHE)
Fact_OHE$SRC_CLAIM_NBR = as.factor(Fact_OHE$SRC_CLAIM_NBR)

####################################
### Brining Fact data at SRC_CLAIM_NBR level

Fact_OHE_1 = Fact_OHE %>%
  group_by(SRC_CLAIM_NBR) %>% 
  summarise_each(funs(max))

#########################################
## Checking the FACT_OHE_1

df2 <- as.vector(as.matrix(Fact_OHE_1[ , 2:184]))
unique(df2)


rm(df2)
#################################################
## Getting the Mod_Cnt column

MOD_CNT = ifelse(is.na(Fact_cols$CPT_MOD_CD),0,ifelse(is.na(Fact_cols$CPT_MOD_CD2),1,2))


### Bringing Numeric data at claim level

Num_Cols$MOD_CNT = MOD_CNT

Num_Cols$SRC_CLAIM_NBR = as.factor(Num_Cols$SRC_CLAIM_NBR)

Cols_Stand = Num_Cols[ ,c('SRC_CLAIM_NBR', "NET_PAID_AMT","SERV_UNIT_CNT","MBR_AGE","DIAG_CNT"  )]

Cols_Stand = Cols_Stand %>%
  group_by(SRC_CLAIM_NBR) %>% 
  summarise_each(funs(mean))

## Scaling the Numeric columns

## Feature Scaling

library(tidyverse)
library(dplyr)

Num_Cols$SRC_CLAIM_NBR = as.factor(Num_Cols$SRC_CLAIM_NBR)
Num_Cols$FIND_FLAG = as.factor(as.character(Num_Cols$FIND_FLAG))

### Standardizing the required columns

a = preProcess(Cols_Stand[ ,2:5], method = "range")
Stand_Data = predict(a, Cols_Stand[ ,2:5])

## MOD_CNT Standardization

MOD_CNT = Num_Cols[ , c('SRC_CLAIM_NBR', 'MOD_CNT')]

MOD_CNT = MOD_CNT %>%
  group_by(SRC_CLAIM_NBR) %>% 
  summarise_each(funs(max))

b= preProcess(MOD_CNT[ ,2], method = "range")
Mod_Cnt = predict(b, MOD_CNT[ ,2])

#################################################
## Summarizing Rev Codes and Prov HitRate at claim_nbr

Rev_Cd = Num_Cols[ ,c('SRC_CLAIM_NBR', 'REV_0636',	'REV_0335',	'REV_0260',	'REV_0360',	'REV_0551',	'REV_0450',	'REV_0331',	'REV_0940',	'REV_0761',	'REV_0361',	'REV_0490',	'REV_0421',	'REV_0510',	'REV_0390',	'REV_OTHER', "PROV_HIT_RATE" )]

Rev_Cd = Rev_Cd %>%
  group_by(SRC_CLAIM_NBR) %>% 
  summarise_each(funs(max))

##############################################
## Getting the FIND_FLAG at Cliam_level

Num_Cols$FIND_FLAG = as.numeric(as.character(Num_Cols$FIND_FLAG))

FIND_FLAG = Num_Cols[ , c('SRC_CLAIM_NBR', 'FIND_FLAG')]

FIND_FLAG = FIND_FLAG %>%
  group_by(SRC_CLAIM_NBR) %>% 
  summarise_each(funs(max))

FIND_FLAG$FIND_FLAG = as.factor(as.character(FIND_FLAG$FIND_FLAG))


#### Merging the Numeric and Factor variables

Num_Data_Final = cbind(Cols_Stand[,1], Stand_Data, Mod_Cnt, Rev_Cd[,2:17])

Data_Final = merge(merge(Fact_OHE_1, Num_Data_Final, by = 'SRC_CLAIM_NBR'), FIND_FLAG, by = 'SRC_CLAIM_NBR' ) 

#########################################################
### Removing unrequired datasets

rm(char_cols, Fact_Cols,Mod_Cnt, Claim_Cnt, Cols_Stand, Comb_Fact_Data, Fact_cols, Fact_OHE,  Findings_Base, MOD_CNT, Num_Cols,Rev_Cd, Stand_Data, df2, z, x, FIND_FLAG)

save.image("Final_Data_ANN.RData")

#########################################################