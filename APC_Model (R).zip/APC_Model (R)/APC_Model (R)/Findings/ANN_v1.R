###########################
### Setting the work directory

setwd("U:/APC_Model (R)/Findings")

###########################
### Getting the model_data

load("Final_Data_ANN.RData")

rm(a, b, Fact_OHE_1, Num_Data_Final)

##############################
##Getting required libraries

library(caTools)
library(h2o)

options(java.parameters = "-Xmx8g")

h2o.init(ip = "localhost", nthreads = -1, ignore_config = TRUE, min_mem_size = "6g")


###################################
## Replacing the NULLS in the Data_Final with 0 for Prov_HitRate

Data_Final$PROV_HIT_RATE[which(is.na(Data_Final$PROV_HIT_RATE))] = 0

#### Splitting the data into Train and Test


Samp = sample(3, nrow(Data_Final), replace = TRUE, prob = c(0.6,0.2,0.2))

train_data = Data_Final[Samp==1,]
test_data =  Data_Final[Samp==2,]
valid_data = Data_Final[Samp==3,]

## Checking the %age of FIND_FLAG in test and train

prop.table(table(train_data$FIND_FLAG))   ##13.38%
prop.table(table(test_data$FIND_FLAG))   ##12.94%
prop.table(table(valid_data$FIND_FLAG))  ##13.31%


#########################
##Removing SRC_CLAIM_NBR from train_data

train_data$SRC_CLAIM_NBR = NULL

## Model Building

Sys.time()

response = "FIND_FLAG"

predictors = setdiff(names(train_data), response)

#####################
## Grid search for ANN
#################################################
#################################################


ann_params2 = list( epochs = c(100, 200),
                    train_samples_per_iteration = c(5000, 10000, -2),
                    rate = c(0.05,0.01, 0.005),
                    l2 = c(0.2,0) )


Sys.time()
ann_grid_v1 <- h2o.grid("deeplearning", 
                      y = response,
                      x = predictors,
                      activation = "Rectifier",
                      training_frame = as.h2o(train_data),
                      grid_id = "ann_grid_v2",
                      validation_frame = as.h2o(test_data[,-c(1)]),
                      hidden = c(110),
                      nfolds = 20,
                      balance_classes = TRUE,
                   variable_importances = T,
                      fold_assignment = 'Random',
                   input_dropout_ratio = 0.1,
                      hyper_params = ann_params2)


 
Sys.time()



h2o.saveGrid("\\\\LOUISILON02S/USERDAT01/rks6701/Desktop/Roushan/APC_ReTraining - Model 4.0/Model 4.0/Findings/ANN_Grid",grid_id = ann_grid_v1@grid_id )


Sys.time()

ann_acc <- h2o.getGrid(grid_id = "ann_grid_v2",
                             sort_by = "accuracy",
                             decreasing = TRUE)

### ann_grid_v2_model_12
#epochs  l2  rate train_samples_per_iteration
#7.82    0.0 0.005  5000 


ann_f1<- h2o.getGrid(grid_id = "ann_grid_v2",
                             sort_by = "f1",
                             decreasing = TRUE)

# ann_grid_v2_model_8
# epochs  l2  rate train_samples_per_iteration
# 7.76    0.0  0.01    5000

#######################################################
#######################################################



#################################################
## Predicting on test data (best accuracy)


a =h2o.getModel("ann_grid_v2_model_12")

## Test_data Prediction
pred_1 = h2o.predict(a, newdata = as.h2o(test_data))
pred_1 = as.data.frame(pred_1)
caret::confusionMatrix (pred_1$predict, test_data$FIND_FLAG, positive = '1')


x = ifelse(pred_1$p1>0.35,1,0)
x = as.factor(x)
caret::confusionMatrix (x, test_data$FIND_FLAG, positive = '1')


## Test_data - Accuracy

Output_Acc_test = cbind(test_data[,c("SRC_CLAIM_NBR", "FIND_FLAG")], pred_1)

write.csv(Output_Acc_test, "Output_Acc_Test.csv")




#### Valid Data
pred_1 = h2o.predict(a, newdata = as.h2o(valid_data))
pred_1 = as.data.frame(pred_1)
caret::confusionMatrix (pred_1$predict, valid_data$FIND_FLAG, positive = '1')


x = ifelse(pred_1$p1>0.2,1,0)
x = as.factor(x)
caret::confusionMatrix (x, valid_data$FIND_FLAG, positive = '1')


## Valid_data - Acc Score

Output_Acc_Valid = cbind(valid_data[,c("SRC_CLAIM_NBR", "FIND_FLAG")], pred_1)

write.csv(Output_Acc_Valid, "Output_Valid_Acc.csv")




##############################################
### Predicting on test & validation data for best f1 score model



a =h2o.getModel("ann_grid_v2_model_8")


#######n Valid_data

pred_1 = h2o.predict(ann_f1, newdata = as.h2o(valid_data))
pred_1 = as.data.frame(pred_1)
caret::confusionMatrix (pred_1$predict, valid_data$FIND_FLAG, positive = '1')


x = ifelse(pred_1$p1>0.25,1,0)
x = as.factor(x)
caret::confusionMatrix (x, valid_data$FIND_FLAG, positive = '1')



## Valid_data - f1 Score

Output_Valid_f1 = cbind(valid_data[,c("SRC_CLAIM_NBR", "FIND_FLAG")], pred_1)

write.csv(Output_Valid_f1, "Output_Valid_f1.csv")


###n Test _data
pred_1 = h2o.predict(ann_f1, newdata = as.h2o(test_data))
pred_1 = as.data.frame(pred_1)
caret::confusionMatrix (pred_1$predict, test_data$FIND_FLAG, positive = '1')


x = ifelse(pred_1$p1>0.5,1,0)
x = as.factor(x)
caret::confusionMatrix (x, test_data$FIND_FLAG, positive = '1')

################################################
################################################


### Cbinding the output with SRC_CLAIM_NBR


Output_test_f1 = cbind(test_data[,c("SRC_CLAIM_NBR", "FIND_FLAG")], pred_1)

write.csv(Output_test_f1, "Output_test_f1.csv")


######################
## Models 12 (accuracy) and 8 (f1 score)


#######################

save.image("//louisilon02s/USERDAT01/rks6701/Desktop/Roushan/APC_ReTraining - Model 4.0/Model 4.0/Findings/Final_Ann_Dataset.RData")