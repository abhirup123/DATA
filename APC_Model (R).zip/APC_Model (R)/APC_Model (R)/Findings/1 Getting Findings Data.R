#######
##Setting work directory

setwd("U:/APC_Model (R)/Findings")

#############################
##Loading the required libraries


library("RODBC")
library(dplyr)

###############################

id = "fr_hgs_sandbox"
pass = "music#17"

conn <- odbcConnect(dsn = "APC_DATA", uid = id, pwd = pass)

odbcQuery(conn,  "select * from fr_hgs_sandbox.rks_model4_Findings_Base4 ") 



Findings_Base = sqlGetResults(conn, 
                             nullstring = NA_character_, na.strings = "NA",
                             dec = getOption("dec"),
                             stringsAsFactors = default.stringsAsFactors())





###############################
####Saving the data

save.image("1 Findings RAW Data.RData")
